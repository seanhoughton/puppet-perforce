Welcome
=======
This is a test harness for the Perforce Unix SDP (Server Deployment Package). 
It used to use Vagrant, but has now been converted to use Docker containers (see older
versions of this file for Vagrant instructions).

Requirements
------------
To use this bundle you will need to download and install the following free tool:

https://docs.docker.com/engine/installation/

If you're not familiar with Docker, it is building up a huge momentum because of its
sweet spot functionality which addresses fast creation of virtual environments and
the ability to ship images with all dependencies between different environments.

https://docs.docker.com/mac/

Usage
-----
1) Have a workspace which looks like (assuming name of myws.sdp):   

    View:
        //guest/perforce_software/sdp/main/... //myws.sdp/sdp/...
        //guest/perforce_software/sdp/main/test/* //myws.sdp/*

2) sync the workspace

3) From the command prompt run run_docker_tests.sh from the root directory. The first time 
you run it will take a while as it builds the initial docker images!

Workflow for testing
--------------------

Build your docker image (from workspace root):

1) docker build --rm=true -t=ubuntu-sdp -f sdp/test/docker/Dockerfile.centos6.sdp sdp/test/docker

How to run all tests:

1) docker run --rm -v `pwd`/sdp:/sdp centos6-sdp /p4/docker_entry.sh

How to interactively poke around inside the container:

1) docker run --rm -v `pwd`/sdp:/sdp -it centos6-sdp /bin/bash
2) Run 'sudo su - perforce' to become user perforce (home directory is /p4)
3) /p4/test_sdp.sh

Substitute 'centos' for 'ubuntu' for different distribution in above commands.
