#!/bin/bash
# This script sets up the base docker container for use with SDP testing.
# It expects to be run as root within the container.

# Create base directories for use by SDP (see mkdirs.sh)
mkdir /hxdepots
mkdir /hxmetadata1
mkdir /hxmetadata2
mkdir /hxlogs

# Create Perforce group and user within that group, and allow them sudo privileges
groupadd perforce
useradd -d /p4 -s /bin/bash -m perforce -g perforce
echo 'perforce ALL=(ALL) NOPASSWD:ALL'> /tmp/perforce
chmod 0440 /tmp/perforce
chown root:root /tmp/perforce
mv /tmp/perforce /etc/sudoers.d
echo perforce:Password | chpasswd

#
# Helpful profile for perforce user login profile - for manual testing mainly
#
BASH_PROF=/p4/.bash_profile
echo 'export PATH=/sdp/Server/Unix/p4/common/bin:$PATH'> $BASH_PROF
echo 'export P4CONFIG=.p4config'>> $BASH_PROF
echo 'export P4P4PORT=1666'>> $BASH_PROF
chown perforce:perforce $BASH_PROF

#
# Script to reset SDP for tests in case of multiple runs.
#
RESET_SDP=/p4/reset_sdp.sh
echo '#!/bin/bash'> $RESET_SDP
echo 'sudo cp -R /sdp /hxdepots'>> $RESET_SDP
echo 'sudo chown -R perforce:perforce /hxdepots/sdp'>> $RESET_SDP
chmod +x $RESET_SDP
chown perforce:perforce $RESET_SDP

#
# Script to run SDP tests - run by Docker entry script below (or can be run
# manually).
#
RUN_SDP_TESTS=/p4/test_sdp.sh
echo '#!/bin/bash'> $RUN_SDP_TESTS
echo '/p4/reset_sdp.sh'>> $RUN_SDP_TESTS
echo 'ln -s /sdp/Server/test/test_SDP.py /p4/test_SDP.py'>> $RUN_SDP_TESTS
echo 'python3.4 /p4/test_SDP.py'>> $RUN_SDP_TESTS
echo 'result=$?'>> $RUN_SDP_TESTS
echo '[[ $result -eq 0 ]] || tail /tmp/SDPTest.log'>> $RUN_SDP_TESTS
echo 'exit $result'>> $RUN_SDP_TESTS
chmod +x $RUN_SDP_TESTS
chown perforce:perforce $RUN_SDP_TESTS

#
# The file run by docker - just runs the above script as perforce user
# Note that the output file is collected by script run_docker_tests.sh
#
DOCKER_ENTRY=/p4/docker_entry.sh
echo '#!/bin/bash'> $DOCKER_ENTRY
echo 'su -l perforce -c /p4/test_sdp.sh > /sdp/test/output/test-${TESTOS}.out 2>&1'>> $DOCKER_ENTRY
chmod +x $DOCKER_ENTRY
chown perforce:perforce $DOCKER_ENTRY
