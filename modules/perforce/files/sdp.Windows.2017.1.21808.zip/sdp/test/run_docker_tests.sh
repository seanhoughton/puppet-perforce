#!/bin/bash
# Run the Docker tests for the SDP
# Note that this file is expecting to be mapped into the root of the workspace
# and with the sdp directory in the same root.
# So workspace view should look something like:
#    View:
#        //guest/perforce_software/sdp/main/... //myws.sdp/sdp/...
#        //guest/perforce_software/sdp/main/test/* //myws.sdp/*

# Perforce version being tested
P4VER=16.1

oses=""

# Allow the specific platform to be specified via parameter
if [ ,"$1" = ,"ubuntu" ] ; then
	oses="ubuntu"
elif [ ,"$1" = ,"centos" ] ; then
	oses="centos6"
elif [ ,"$1" = ,"centos6" ] ; then
	oses="centos6"
elif [ ,"$1" = ,"centos7" ] ; then
	oses="centos7"
else
	oses="ubuntu centos6 centos7"
fi

# Directory where test output is put by the container
# Easier to make it under sdp which is a mounted volume
test_output_dir="./sdp/test/output"
[[ -d "$test_output_dir" ]] || mkdir "$test_output_dir"
all_test_output="$test_output_dir/alltests.out"
if [ -f $all_test_output ] ; then
	rm $all_test_output
fi

# Make sure that p4 binaries are present and correct
origdir=`pwd`
cd ./sdp/Server/Unix/p4/common/bin
if [ ! -f p4 ]; then
	wget -nv ftp.perforce.com/perforce/r$P4VER/bin.linux26x86_64/p4
fi
if [ ! -f p4d ]; then
	wget -nv ftp.perforce.com/perforce/r$P4VER/bin.linux26x86_64/p4d
fi
cd $origdir

echo Running SDP tests
tests_failed=0
for os in $oses
do
	test_output="$test_output_dir/test-${os}.out"
	if [[ -f $test_output ]]; then
	    rm $test_output
	fi
	docker_dir=sdp/test/docker
	dockerfile_base=${docker_dir}/Dockerfile.${os}.base
	dockerfile_sdp=${docker_dir}/Dockerfile.${os}.sdp
	# Build the base Docker for the OS, and then the SDP variant on top
	docker build --rm=true -t=${os}-base -f ${dockerfile_base} ${docker_dir}
	# Note that by 
	docker build --rm=true -t=${os}-sdp -f ${dockerfile_sdp} ${docker_dir}
	# Run the Docker image, mounting the /sdp directory within it. The SDP image
	# has a default RUN command which is configured within it.
	# We don't directly stop on error but process a little later below so that nice
	# messages are written to Jenkins console outut.
    set +e
	docker run --rm  -v ${origdir}/sdp:/sdp -e TESTOS=${os} ${os}-sdp
    tests_failed=$?
    set -e
	echo $os>> $all_test_output
	# Avoid Jenkins immediately failing job without letting us cat the output
	set +e
	cat $test_output>> $all_test_output
	set -e
	if [ $tests_failed -ne 0 ]; then
		break
	fi 
done
cat $all_test_output
exit $tests_failed
