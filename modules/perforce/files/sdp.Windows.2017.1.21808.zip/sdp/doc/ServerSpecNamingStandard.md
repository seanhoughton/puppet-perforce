Server Spec Naming Standard
===

Server spec names provide info at a glance - where the server is physically located, whether it is filtered (as filtering disqualifies a replica from being an edge server target), and the type of replica (read-on, forwarding, or edge).

The naming convention intentionally does not account for all possible server specs available with p4d.  The standard accounts only for the distilled list of server spec types supported by HMS, which are the most useful and commonly used ones.

The general form is:

*HelixServer*\_*ReplicaType*\_*SiteTag*

Where:

*HelixServer* is one of:

* p4d
* p4broker
* p4p
* p4web
* p4gf
* swarm

*ReplicaType* is one of:

* master - A Master/Commit server (not a replica at all)
* fr - Forwarding Replica
* ffr - Filtered Forwarding Replica (Note: Filtered replicas are not valid failover targets).
* ro - Read Only replica
* edge - Edge server

*SiteTag* looks something like these samples:
* syd - Sydney, Australia
* bos - Boston, MA, USA
* blr - Bangalore, India

The site tag needs to distinguish the data centers used by a single enterprise, and so generally short tag names are appropriate.  Each site tag may be understood to be a true data center (Tier 1, Tier 4, etc.), a computer room, computer closet, or reserved space under a developer's desk.

For master server specs, we drop the geo tag and server type.

Sample server spec names:
* p4d_fr_chi
* p4d_fr_pune
* p4d_edge_blr


