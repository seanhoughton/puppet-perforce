#!/usr/bin/env python
# ==============================================================================
# Copyright and license info is available in the LICENSE file included with
# the Server Deployment Package (SDP), and also available online:
# https://swarm.workshop.perforce.com/projects/perforce-software-sdp/view/main/LICENSE
# ------------------------------------------------------------------------------

"""
Usage:
 	describe_shelves.py

This script will describe all the shelves on the server. It is used to cause a
replica server to pull all of the shelved files to the replica.
"""

# Python 2.7/3.3 compatibility.
from __future__ import print_function

import os
import re
import sys
import sdputils

if len(sys.argv) > 1:
    SDP_INSTANCE = str(sys.argv[1])
else:
    SDP_INSTANCE = '1'

utils = sdputils.SDPUtils(SDP_INSTANCE)
config = utils.config
p4 = utils.p4
utils.login()

def main():
    os.system("%s changes -s shelved > shelved.txt" % p4)

    input = open("shelved.txt", "r")

    for line in input.readlines():
        line = line.rstrip()
        line = re.sub(r"^Change", r"%s describe -S" % p4, line)
        line = re.sub(r" on .*", "", line)
        os.system(line)

    input.close()
    os.remove("shelved.txt")

if __name__ == "__main__":
    main()
