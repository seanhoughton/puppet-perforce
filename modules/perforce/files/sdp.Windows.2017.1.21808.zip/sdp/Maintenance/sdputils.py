#!/usr/bin/env python
# ==============================================================================
# Copyright and license info is available in the LICENSE file included with
# the Server Deployment Package (SDP), and also available online:
# https://swarm.workshop.perforce.com/projects/perforce-software-sdp/view/main/LICENSE
# ------------------------------------------------------------------------------

"""
This module is a convenience for other modules in this directory
"""

# Python 2.7/3.3 compatibility.
from __future__ import print_function

import os
import sys
import platform

class Options:
    server = None
    p4user = None
    passwd = None
    weeks = None
    rawconfig = None

    def get(self, varname):
        return self.rawconfig.get(self.sdp_instance, varname)

class SDPUtils:

    def __init__(self, sdp_instance):
        self.config = Options()
        self.sdp_instance = sdp_instance
        self.config.sdp_instance = sdp_instance

        # Python 2.7/3.3 compatibility.
        if sys.version_info[0] >= 3:
            import configparser
            self.rawconfig = configparser.RawConfigParser()
        else:
            import ConfigParser
            self.rawconfig = ConfigParser.RawConfigParser()

        self.config.rawconfig = self.rawconfig

        ##########################################################################
        #####                                                                #####
        #####  CONFIGURATION VARIABLES: Modify in maintenance.cfg as needed. #####
        #####                                                                #####
        self.rawconfig.read('maintenance.cfg')
        self.config = Options()
        self.config.server = self.rawconfig.get(self.sdp_instance, 'server')
        self.config.p4user = self.rawconfig.get(self.sdp_instance, 'p4user')
        self.config.passwd = self.rawconfig.get(self.sdp_instance, 'passwd')
        self.config.weeks = int(self.rawconfig.get(self.sdp_instance, 'weeks'))

        if platform.system() == "Windows":
            self.p4 = "p4.exe -p %s -u %s" % (self.config.server, self.config.p4user)
        else:
            self.p4 = "/p4/%s/bin/p4_%s  -p %s -u %s" % (self.sdp_instance, self.sdp_instance,
                                                         self.config.server, self.config.p4user)

    def get(self, varname):
        return self.rawconfig.get(self.sdp_instance, varname)

    def login(self):
        os.system('echo %s| %s login' % (self.config.passwd, self.p4))
