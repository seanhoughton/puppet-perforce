SDP Maintenance scripts

These are example scripts which have proven useful in the past.

They are NOT fully tested and NOT guaranteed to work. Treat with some caution!!!
