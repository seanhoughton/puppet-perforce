#!/usr/bin/env python
# ==============================================================================
# Copyright and license info is available in the LICENSE file included with
# the Server Deployment Package (SDP), and also available online:
# https://swarm.workshop.perforce.com/projects/perforce-software-sdp/view/main/LICENSE
# ------------------------------------------------------------------------------

"""
 Usage:
	delusers.py

 What this scripts does:
	Calls p4deleteusers.py automain module which will remove allusers that haven't
	accessed Perforce in the variable weeks set in maintenance.cfg
"""

import os
import p4deleteuser


######################################################################################################
def main():
    p4deleteuser.automain()
    os.remove("users.txt")


######################################################################################################
if __name__ == '__main__':
    main()
