#!/usr/bin/env python
#==============================================================================
# Copyright and license info is available in the LICENSE file included with
# the Server Deployment Package (SDP), and also available online:
# https://swarm.workshop.perforce.com/projects/perforce-software-sdp/view/main/LICENSE
#------------------------------------------------------------------------------

"""
Usage:
 	remove_empty_pending_changes.py

This script will remove all of the empty pending changelists on the server.
"""

import os
import re
import sys
import sdputils

if len(sys.argv) > 1:  # see params above
    SDP_INSTANCE = str(sys.argv[1])
else:
    SDP_INSTANCE = '1'

utils = sdputils.SDPUtils(SDP_INSTANCE)
config = utils.config
p4 = utils.p4
utils.login()


def main():
  os.system( '%s changes -s pending | cut -d " " -f 2 > pending.txt' % p4 )

  input = open( "pending.txt", "r" )

  for changenum in input.readlines():
    changenum = changenum.strip()
    # Need to check to see if user is swarm and skip
    for user in os.popen('%s -Ztag describe -s %s | grep "user swarm"' % (p4, changenum)):
      if ('swarm' in user):
        continue
    os.system ('%s change -fd %s' % (p4, changenum))

  input.close()
  os.remove( "pending.txt" )


###############################################################################
# main
if __name__ == "__main__":
    main()
