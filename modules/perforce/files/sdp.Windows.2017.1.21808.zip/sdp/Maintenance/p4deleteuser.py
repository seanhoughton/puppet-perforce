#!/usr/bin/env python
# ==============================================================================
# Copyright and license info is available in the LICENSE file included with
# the Server Deployment Package (SDP), and also available online:
# https://swarm.workshop.perforce.com/projects/perforce-software-sdp/view/main/LICENSE
# ------------------------------------------------------------------------------

# Usage:
#	p4deleteuser.py [instance] user_to_remove
#	p4deleteuser.py [instance] file_with_users_to_remove
#
# What this scripts does:
#   Removes user and any clients/shelves owned by that user.
#
# instance defaults to 1 if not given.

import os
import sys
import accessdates
import removeuserfromgroups
import re
import sdputils

if len(sys.argv) > 2:  # see params above
    SDP_INSTANCE = str(sys.argv[1])
else:
    SDP_INSTANCE = '1'

utils = sdputils.SDPUtils(SDP_INSTANCE)
config = utils.config
p4 = utils.p4
utils.login()

sim = 0
clientlist = []

######################################################################################################
def delete_clients(clientlist, sim):
    for client in clientlist:
        print("Deleting Client: '%s'" % (client))
        if sim == 0:
            client = client.rstrip()
            os.system("%s -Ztag changes -s shelved -c '%s' > shelved.txt" % (p4, client))
            if(os.path.isfile("shelved.txt")):
                shelvedfile = open("shelved.txt", "r")
                for changeline in shelvedfile.readlines():
                    if re.search("\.\.\. change ", changeline):
                        changenum = changeline[11:]
                        changenum = changenum.strip()
                        os.system("%s shelve -c '%s' -df" % (p4, changenum))
                shelvedfile.close()
                os.remove("shelved.txt")
            try:
                os.system("%s client -df -Fs '%s'" % (p4, client))
            except:
                try:
                    os.system("%s client -df -Fs '%s'" % (p4, client))
                except:
                    print("Could not delete client '%s'" % client)


######################################################################################################
def delete_users(userlist, sim):
    for user in userlist:
        print("Deleting User: '%s'" % user)
        if sim == 0:
            os.system("%s user -f -d '%s'" % (p4, user))


######################################################################################################
def get_clients(userlist):
    for user in userlist:
        for line in os.popen("%s clients -u '%s'" % (p4, user)):
            client = line.split()[1]
            clientlist.append(client)
        for line in os.popen("%s clients -u '%s' -U" % (p4, user)):
            client = line.split()[1]
            clientlist.append(client)
        for line in os.popen("%s opened -u '%s'" % (p4, user)):
            client = re.sub('.*\@', '', line)
            client = re.sub('\*exclusive\*', '', client)
            client = re.sub('\*locked\*', '', client)
            client = client.strip()
            if client not in clientlist:
                clientlist.append(client)


######################################################################################################
def cleanup():
    os.remove('groups.txt')


######################################################################################################
def setup():
    os.system('%s groups > groups.txt' % p4)


######################################################################################################
def mainbody(userorfile):
    userlist = []

    try:
        input = open(userorfile, "r")
    except:
        print("Unable to open file %s assuming it is the username." % userorfile)
        user = userorfile.strip()
        userlist.append(user)
        removeuserfromgroups.automain(userlist)
        get_clients(userlist)
        delete_clients(clientlist, sim)
        delete_users(userlist, sim)
        cleanup()
        sys.exit(0)

    p4users = os.popen('p4 users | cut -d " " -f1').read()

    for line in input.readlines():
        line = line.rstrip()
        if (line in p4users):
            userlist.append(line)

    input.close()

    removeuserfromgroups.automain(userlist)
    get_clients(userlist)
    delete_clients(clientlist, sim)
    delete_users(userlist, sim)
    cleanup()


######################################################################################################
def automain():
    accessdates.createlist("users", "user", config.weeks)
    setup()
    mainbody("users.txt")


######################################################################################################
def main():
    if len(sys.argv) < 2:
        print("Read the usage section at the top of the script for required parameters.")
        sys.exit(1)

    setup()

    # Handle the optional instance parameter shift
    if len(sys.argv) > 2:
        mainbody(sys.argv[2])
    else:
        mainbody(sys.argv[1])


######################################################################################################
if __name__ == '__main__':
    main()
