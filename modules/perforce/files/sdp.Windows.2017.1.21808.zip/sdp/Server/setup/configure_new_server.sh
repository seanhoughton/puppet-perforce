#!/bin/bash
#==============================================================================
# Copyright and license info is available in the LICENSE file included with
# the Server Deployment Package (SDP), and also available online:
# https://swarm.workshop.perforce.com/projects/perforce-software-sdp/view/main/LICENSE
#------------------------------------------------------------------------------
# Set P4PORT and P4USER and run p4 login before running this script.

# Verify instance value
INSTANCE=$1
if [[ -n "$INSTANCE" ]]; then
   source /p4/common/bin/p4_vars $INSTANCE
else
    echo "Error: An instance argument is required."
    exit 1
fi

# Basic secruity features.
p4 configure set run.users.authorize=1

# The server.depot.root configurable was introduced in 2014.1.
if [[ "$P4D_VERSION" > "2014.1" ]]; then
   p4 configure set server.depot.root=$DEPOTS
fi

p4 configure set journalPrefix=$CHECKPOINTS/p4_${INSTANCE}
p4 configure set dm.user.noautocreate=2
# p4 configure set dm.user.resetpassword=1
p4 configure set filesys.P4ROOT.min=5G
p4 configure set filesys.depot.min=5G
p4 configure set filesys.P4JOURNAL.min=5G

p4 configure set server=4
p4 configure set monitor=1

# For P4D 2013.2+, setting db.reorg.disable=1, which turns off
# dynamic database reorg, has been shown to significantly improve
# performance when Perforce databases (db.* files) are stored on
# some solid state storage devices, while not making a difference
# on others.
[[ "$P4D_VERSION" > "2013.1" ]] && p4 configure set db.reorg.disable=1

# Set net.tcpsize to 512k when P4D is 2014.2 or less.  In 2014.2
# the default value become 512k.  For newer versions of p4d, set
# net.tcpsize explicitly to 0 to engage auto-self-tuning feature.
if [[ "$P4D_VERSION" < "2014.2" ]]; then
   p4 configure set net.tcpsize=512k
else
   p4 configure set net.tcpsize=0
fi

p4 configure set net.backlog=2048

p4 configure set lbr.autocompress=1
p4 configure set lbr.bufsize=1M
p4 configure set serverlog.file.3=$LOGS/errors.csv
p4 configure set serverlog.retain.3=$KEEPLOGS
# Commented out since we aren't selling Interset Threat Detection anymore.
# p4 configure set serverlog.file.4=$LOGS/audit.csv
# p4 configure set serverlog.retain.4=$KEEPLOGS
p4 configure set serverlog.file.7=$LOGS/events.csv
p4 configure set serverlog.retain.7=$KEEPLOGS
p4 configure set serverlog.file.8=$LOGS/integrity.csv
p4 configure set serverlog.retain.8=$KEEPLOGS

echo "Creating a depot named 'spec' of type 'spec'."
p4 depot -i < spec.depot.p4s

echo "Creating a depot named 'unload' of unload 'unload'."
p4 depot -i < unload.depot.p4s

# Load shedding and other performance-preserving configurable.
# See: http://answers.perforce.com/articles/KB/1272
# For p4d 2013.1+
[[ "$P4D_VERSION" > "2013.1" ]] && p4 configure set server.maxcommands=2500

# For p4d 2013.2+ -Turn off max* commandline overrides.
[[ "$P4D_VERSION" > "2013.2" ]] && p4 configure set server.commandlimits=2

echo See http://www.perforce.com/perforce/doc.current/manuals/p4dist/chapter.replication.html#replication.verifying
echo if you are also setting up a replica server.
p4 configure set rpl.checksum.auto=1
p4 configure set rpl.checksum.change=2
p4 configure set rpl.checksum.table=1

# For p4d 2016.1 Patch 2+, disable auto prompting for a password, as this
# can cause 'p4' commands to go interactive that wouldn't normally,
# wreaking havoc with automation.
if [[ "$P4D_VERSION" > "2016.1.1395782" ]]; then
   p4 configure set auth.autologinprompt=0
fi

# For p4d 2016.1 Patch 5+
# Enable a server with an expired temp license to start, albeit with limited
# functionality, so that license expiry doesn't make it impossible to perform
# license management via the front-door.  This configurable allows the server
# to be started regardless of a bad license, though users will still be blocked
# by license invalid messages.  Perpetual commercial licenses never expire;
# this configurable will not affect those.
if [[ "$P4D_VERSION" > "2016.1.1408676" ]]; then
   p4 configure set server.start.unlicensed=1
fi

# Starting with p4d 2015.1 Patch 5, disallow P4EXP v2014.2 (a client
# version known to misbehave) from connecting to the server.
# See:  http://answers.perforce.com/articles/KB/15014
if [[ "$P4D_VERSION" > "2015.1.1126924" ]]; then
   p4 configure set "rejectList=P4EXP,version=2014.2"
fi

# For p4d 2011.1 thru 2015.1, set rpl.compress=3.  For p4d 2015.2+, set
# rpl.compress=4.  This setting compresses journal data only, which is
# almost always advantageous as it compresses well, while avoiding
# compression of archive data, which is a mixed bag in terms of performance
# benefits, and potentially a net netagive.
# server.global.views - makes client views global in a commit/edge or cluster environment.
if [[ "$P4D_VERSION" > "2015.2" ]]; then
   p4 configure set rpl.compress=4
   p4 configure set server.global.client.views=1
elif [[ "$P4D_VERSION" > "2011.1" ]]; then
   p4 configure set rpl.compress=3
fi

# Starting with p4d 2016.2, enable these features.
if [[ "$P4D_VERSION" > "2016.2" ]]; then
   p4 configure set filesys.checklinks=2
   p4 configure set server.locks.global=1
   p4 configure set proxy.monitor.level=3
fi

# Recommended for Swarm
p4 configure set dm.shelve.promote=1
p4 configure set dm.keys.hide=2

# Starting with p4d 2016.1, use auth.id to simplify ticket handling.
# After setting auth.id, login again.
if [[ "$P4D_VERSION" > "2016.1" ]]; then
   p4 configure set rpl.forward.login=1
   p4 configure set auth.id=$P4SERVER
   $P4CBIN/p4login
fi

# Set SDP version identifing info.
p4 counter SDP_DATE `date "+%Y-%m-%d"`
p4 counter SDP_VERSION "$SDP_VERSION"

# Restart to ensure all configurable changes take effect.
p4 admin restart

echo -e "\nIt is recommended that you run 'p4 configure set security=3' or\n'p4 configure set security=4'.\nSee: http://www.perforce.com/perforce/doc.current/manuals/p4sag/chapter.superuser.html#DB5-49899\n"

