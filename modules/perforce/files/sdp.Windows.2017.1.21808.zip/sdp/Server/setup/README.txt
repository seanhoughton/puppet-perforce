See the Windows specific setup files in:

..\Windows\setup

In particular:

SDPEnv.py
template_configure_new_server.bat
